DATASTAR - Prototype version Mk.2

In-game controls are now fully customizable, the following for UI:
  - Arrow keys to navigate within menus
  - Space to confirm in menus and skip intro
  - Escape to return to main menu and go back (in most menus)

Two levels are available, the second is unlocked upon completing the first one
Delete the file bin/savefile.bin to reset progress

The game sometimes fails to launch when opening the .exe, not sure where that comes from, working on it