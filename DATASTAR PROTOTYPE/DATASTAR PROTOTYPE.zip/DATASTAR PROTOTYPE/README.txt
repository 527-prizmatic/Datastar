DATASTAR - Prototype version

Controls:
  - WASD or arrow keys to move
  - Arrow keys to navigate within menus
  - Space to shoot, confirm in menus and skip intro
  - Tab to change weapons
  - Escape to return to main menu